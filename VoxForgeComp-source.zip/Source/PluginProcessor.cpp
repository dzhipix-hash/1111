#include "PluginProcessor.h"
#include "PluginEditor.h"

VoxForgeCompAudioProcessor::VoxForgeCompAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout VoxForgeCompAudioProcessor::createParameterLayout()
{
    using APF = juce::AudioParameterFloat;
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    p.add(std::make_unique<APF>("threshold", "Threshold",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.1f), -18.0f, " dB"));
    p.add(std::make_unique<APF>("ratio", "Ratio",
        juce::NormalisableRange<float>(1.0f, 20.0f, 0.1f), 3.0f, ":1"));
    p.add(std::make_unique<APF>("attack", "Attack",
        juce::NormalisableRange<float>(0.1f, 100.0f, 0.1f, 0.5f), 10.0f, " ms"));
    p.add(std::make_unique<APF>("release", "Release",
        juce::NormalisableRange<float>(10.0f, 1000.0f, 1.0f, 0.5f), 120.0f, " ms"));
    p.add(std::make_unique<APF>("makeup", "Makeup",
        juce::NormalisableRange<float>(-12.0f, 24.0f, 0.1f), 3.0f, " dB"));
    p.add(std::make_unique<APF>("mix", "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f, "%"));
    return p;
}

void VoxForgeCompAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                  (juce::uint32) getTotalNumOutputChannels() };
    compressor.prepare(spec);
    makeup.prepare(spec);
    dryBuffer.setSize(getTotalNumOutputChannels(), samplesPerBlock);
}

bool VoxForgeCompAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return in == out && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

void VoxForgeCompAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = getTotalNumOutputChannels();
    for (int ch = getTotalNumInputChannels(); ch < channels; ++ch)
        buffer.clear(ch, 0, buffer.getNumSamples());

    dryBuffer.makeCopyOf(buffer, true);
    compressor.setThreshold(*parameters.getRawParameterValue("threshold"));
    compressor.setRatio(*parameters.getRawParameterValue("ratio"));
    compressor.setAttack(*parameters.getRawParameterValue("attack"));
    compressor.setRelease(*parameters.getRawParameterValue("release"));

    juce::dsp::AudioBlock<float> block(buffer);
    compressor.process(juce::dsp::ProcessContextReplacing<float>(block));

    makeup.setGainDecibels(*parameters.getRawParameterValue("makeup"));
    makeup.process(juce::dsp::ProcessContextReplacing<float>(block));

    const float wet = *parameters.getRawParameterValue("mix") / 100.0f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        buffer.addFrom(ch, 0, dryBuffer, ch, 0, buffer.getNumSamples(), 1.0f - wet);
}

juce::AudioProcessorEditor* VoxForgeCompAudioProcessor::createEditor()
{
    return new VoxForgeCompAudioProcessorEditor(*this);
}

void VoxForgeCompAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void VoxForgeCompAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VoxForgeCompAudioProcessor();
}
