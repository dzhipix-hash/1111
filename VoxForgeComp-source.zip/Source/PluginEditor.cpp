#include "PluginEditor.h"

VoxForgeCompAudioProcessorEditor::VoxForgeCompAudioProcessorEditor(VoxForgeCompAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(650, 390);
    title.setText("VOXFORGE COMP", juce::dontSendNotification);
    title.setFont(juce::Font(juce::FontOptions(27.0f, juce::Font::bold)));
    title.setColour(juce::Label::textColourId, juce::Colour(0xfff4f6fb));
    addAndMakeVisible(title);
    subtitle.setText("VOCAL DYNAMICS  /  VST3", juce::dontSendNotification);
    subtitle.setFont(juce::Font(juce::FontOptions(11.0f)));
    subtitle.setColour(juce::Label::textColourId, juce::Colour(0xff8d9bb0));
    addAndMakeVisible(subtitle);

    setupKnob(threshold, thresholdLabel, "THRESHOLD");
    setupKnob(ratio, ratioLabel, "RATIO");
    setupKnob(attack, attackLabel, "ATTACK");
    setupKnob(release, releaseLabel, "RELEASE");
    setupKnob(makeup, makeupLabel, "MAKEUP");
    setupKnob(mix, mixLabel, "MIX");

    auto& apvts = audioProcessor.parameters;
    thresholdAttachment = std::make_unique<Attachment>(apvts, "threshold", threshold);
    ratioAttachment = std::make_unique<Attachment>(apvts, "ratio", ratio);
    attackAttachment = std::make_unique<Attachment>(apvts, "attack", attack);
    releaseAttachment = std::make_unique<Attachment>(apvts, "release", release);
    makeupAttachment = std::make_unique<Attachment>(apvts, "makeup", makeup);
    mixAttachment = std::make_unique<Attachment>(apvts, "mix", mix);
}

void VoxForgeCompAudioProcessorEditor::setupKnob(juce::Slider& s, juce::Label& l, const juce::String& name)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 78, 22);
    s.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffffad55));
    s.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff354154));
    s.setColour(juce::Slider::thumbColourId, juce::Colour(0xffffad55));
    s.setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffedf2fa));
    s.setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff202733));
    s.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible(s);
    l.setText(name, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    l.setColour(juce::Label::textColourId, juce::Colour(0xffb7c3d5));
    addAndMakeVisible(l);
}

void VoxForgeCompAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff11151c));
    g.setColour(juce::Colour(0xff202936));
    g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(10.0f), 14.0f);
    g.setColour(juce::Colour(0xffffad55));
    g.fillRoundedRectangle(22.0f, 76.0f, 606.0f, 2.0f, 1.0f);
    g.setColour(juce::Colour(0xff151c26));
    g.fillRoundedRectangle(22.0f, 96.0f, 606.0f, 260.0f, 10.0f);
}

void VoxForgeCompAudioProcessorEditor::resized()
{
    title.setBounds(24, 17, 360, 38);
    subtitle.setBounds(26, 51, 260, 20);
    juce::Slider* sliders[] = { &threshold, &ratio, &attack, &release, &makeup, &mix };
    juce::Label* labels[] = { &thresholdLabel, &ratioLabel, &attackLabel, &releaseLabel, &makeupLabel, &mixLabel };
    const int left = 27, width = 99, gap = 5, top = 122;
    for (int i = 0; i < 6; ++i) {
        const int x = left + i * (width + gap);
        labels[i]->setBounds(x, top, width, 24);
        sliders[i]->setBounds(x, top + 24, width, 180);
    }
}
