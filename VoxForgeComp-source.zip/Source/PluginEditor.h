#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class VoxForgeCompAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit VoxForgeCompAudioProcessorEditor(VoxForgeCompAudioProcessor&);
    ~VoxForgeCompAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    VoxForgeCompAudioProcessor& audioProcessor;
    juce::Label title;
    juce::Label subtitle;
    juce::Slider threshold, ratio, attack, release, makeup, mix;
    juce::Label thresholdLabel, ratioLabel, attackLabel, releaseLabel, makeupLabel, mixLabel;
    using Attachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<Attachment> thresholdAttachment, ratioAttachment, attackAttachment,
        releaseAttachment, makeupAttachment, mixAttachment;
    void setupKnob(juce::Slider&, juce::Label&, const juce::String&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VoxForgeCompAudioProcessorEditor)
};
