@echo off
setlocal
echo =====================================================
echo  VoxForge Comp - Windows VST3 build
echo  Requires Visual Studio 2022 with "Desktop development with C++"
echo  and CMake. JUCE will be downloaded automatically.
echo =====================================================
where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake not found. Install CMake or Visual Studio 2022 C++ tools.
  pause
  exit /b 1
)
if not exist build mkdir build
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 goto fail
cmake --build build --config Release --target VoxForgeComp_VST3
if errorlevel 1 goto fail
echo.
echo Build finished. Look inside build\VoxForgeComp_artefacts\Release\VST3\
pause
exit /b 0
:fail
echo.
echo Build failed. Check the error text above.
pause
exit /b 1
