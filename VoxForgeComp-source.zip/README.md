# VoxForge Comp — vocal compressor VST3

This is a starter JUCE project for a real-time vocal compressor plugin for FL Studio on Windows (64-bit).

## Controls
- Threshold: -60 to 0 dB
- Ratio: 1:1 to 20:1
- Attack: 0.1 to 100 ms
- Release: 10 to 1000 ms
- Makeup: -12 to +24 dB
- Mix: 0 to 100%

## Important
This ZIP contains the **source project**, not a precompiled `.vst3` binary. The current build environment cannot compile Windows binaries directly. To create the plugin, use one of the build paths below.

## Build on Windows
1. Install Visual Studio 2022 and select **Desktop development with C++**. CMake support should be included.
2. Extract this folder.
3. Double-click `build-windows.bat`.
4. When successful, find the VST3 under `build\VoxForgeComp_artefacts\Release\VST3\`.
5. Copy the `VoxForge Comp.vst3` bundle to `C:\Program Files\Common Files\VST3\` if it was not copied automatically.
6. In FL Studio, open **Options → Manage plugins → Find installed plugins**.

The first CMake configure step downloads JUCE from its official GitHub repository, so internet access is needed during the first build.

## Cloud build option
The included `.github/workflows/build-windows.yml` builds the plugin on a Windows GitHub Actions runner and uploads a downloadable artifact. Open the repository's **Actions** tab and run **Build Windows VST3**.

## First release limitations
This is a basic compressor, not a mastering suite. Always compare bypassed and processed levels; high makeup gain can clip. Test on a copy of your vocal first.
